package com.atguigu.gmall.flume.interceptor;

import com.alibaba.fastjson.JSONObject;

public class JsonTest {

    public static void main(String[] args) {

        String jsonStr = "{\"name\":\"zhangsan\"}";
        JSONObject jsonObject = JSONObject.parseObject(jsonStr);
        System.out.println(jsonObject.get("name"));


    }
}
